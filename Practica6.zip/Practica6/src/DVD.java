import java.io.Serializable;

public class DVD extends ElementoBiblioteca implements Serializable {
    private int duracion;

    public DVD(String titulo, int añoPublicacion, String id, int duracion) {
        super(titulo, añoPublicacion, id);
        this.duracion = duracion;
    }

    public int getDuracion() {
        return duracion;
    }

    public void setDuracion(int duracion) {
        this.duracion = duracion;
    }

    @Override
    public void mostrarInformacion() {
        super.mostrarInformacion();
        System.out.println("Duración: " + duracion + " minutos");
    }
}