import java.io.Serializable;

public class Revista extends ElementoBiblioteca implements Serializable {
    private int numeroEjemplares;

    public Revista(String titulo, int añoPublicacion, String id, int numeroEjemplares) {
        super(titulo, añoPublicacion, id);
        this.numeroEjemplares = numeroEjemplares;
    }

    public int getNumeroEjemplares() {
        return numeroEjemplares;
    }

    public void setNumeroEjemplares(int numeroEjemplares) {
        this.numeroEjemplares = numeroEjemplares;
    }

    @Override
    public void mostrarInformacion() {
        super.mostrarInformacion();
        System.out.println("Número de Ejemplares: " + numeroEjemplares);
    }
}