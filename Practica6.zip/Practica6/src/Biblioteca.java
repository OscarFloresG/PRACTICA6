import java.util.ArrayList;
import java.io.*;

public class Biblioteca implements Serializable{
    private ArrayList<ElementoBiblioteca> inventario;

    public Biblioteca() {
        inventario = new ArrayList<>();
        cargarDatos();
    }

    public ArrayList<ElementoBiblioteca> getInventario() {
        return inventario;
    }

    public void agregarElemento(ElementoBiblioteca elemento) {
        inventario.add(elemento);
        guardarDatos();
    }

    public void mostrarInventario() {
        for (ElementoBiblioteca elemento : inventario) {
            elemento.mostrarInformacion();
            System.out.println();
        }
    }

    public ElementoBiblioteca buscarElemento(String id) {
        for (ElementoBiblioteca elemento : inventario) {
            if (elemento.getId().equals(id)) {
                return elemento;
            }
        }
        return null;
    }

    public void actualizarElemento(String id, ElementoBiblioteca nuevoElemento) {
        ElementoBiblioteca elemento = buscarElemento(id);
        if (elemento != null) {
            int index = inventario.indexOf(elemento);
            inventario.set(index, nuevoElemento);
            guardarDatos();
        }
    }

    public void eliminarElemento(String id) {
        ElementoBiblioteca elemento = buscarElemento(id);
        if (elemento != null) {
            inventario.remove(elemento);
            guardarDatos();
        }
    }

    private void guardarDatos() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("inventario.dat"))) {
            oos.writeObject(inventario);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void cargarDatos() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("inventario.dat"))) {
            inventario = (ArrayList<ElementoBiblioteca>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
