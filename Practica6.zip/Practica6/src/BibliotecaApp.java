import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class BibliotecaApp {
    private Biblioteca biblioteca;
    private JFrame frame;
    private JTextArea areaInformacion;

    public BibliotecaApp() {
        biblioteca = new Biblioteca();
        prepararGUI();
    }

    private void prepararGUI() {
        frame = new JFrame("Sistema de Gestión de Biblioteca");
        frame.setSize(400, 400);
        frame.setLayout(new BorderLayout());

        JPanel panelControl = new JPanel();
        panelControl.setLayout(new FlowLayout());

        JButton btnAgregar = new JButton("Agregar");
        JButton btnMostrar = new JButton("Mostrar");
        JButton btnBuscar = new JButton("Buscar");
        JButton btnActualizar = new JButton("Actualizar");
        JButton btnEliminar = new JButton("Eliminar");

        panelControl.add(btnAgregar);
        panelControl.add(btnMostrar);
        panelControl.add(btnBuscar);
        panelControl.add(btnActualizar);
        panelControl.add(btnEliminar);

        areaInformacion = new JTextArea();
        areaInformacion.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(areaInformacion);

        frame.add(panelControl, BorderLayout.NORTH);
        frame.add(scrollPane, BorderLayout.CENTER);

        btnAgregar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                agregarElemento();
            }
        });

        btnMostrar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mostrarInventario();
            }
        });

        btnBuscar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                buscarElemento();
            }
        });

        btnActualizar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                actualizarElemento();
            }
        });

        btnEliminar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                eliminarElemento();
            }
        });

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }

    private void agregarElemento() {
        try {
            String[] opciones = {"Libro", "Revista", "DVD"};
            String tipo = (String) JOptionPane.showInputDialog(frame, "Seleccione el tipo de elemento", "Agregar Elemento",
                    JOptionPane.QUESTION_MESSAGE, null, opciones, opciones[0]);

            if (tipo != null) {
                String titulo = JOptionPane.showInputDialog("Título:");
                int añoPublicacion = Integer.parseInt(JOptionPane.showInputDialog("Año de Publicación:"));
                String id = JOptionPane.showInputDialog("ID:");

                switch (tipo) {
                    case "Libro":
                        int numeroPaginas = Integer.parseInt(JOptionPane.showInputDialog("Número de Páginas:"));
                        biblioteca.agregarElemento(new Libro(titulo, añoPublicacion, id, numeroPaginas));
                        break;
                    case "Revista":
                        int numeroEjemplares = Integer.parseInt(JOptionPane.showInputDialog("Número de Ejemplares:"));
                        biblioteca.agregarElemento(new Revista(titulo, añoPublicacion, id, numeroEjemplares));
                        break;
                    case "DVD":
                        int duracion = Integer.parseInt(JOptionPane.showInputDialog("Duración (minutos):"));
                        biblioteca.agregarElemento(new DVD(titulo, añoPublicacion, id, duracion));
                        break;
                }

                JOptionPane.showMessageDialog(frame, "Elemento agregado exitosamente.");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(frame, "Entrada no válida. Intente de nuevo.");
        }
    }

    private void mostrarInventario() {
        areaInformacion.setText("");
        ArrayList<ElementoBiblioteca> inventario = biblioteca.getInventario();
        if (inventario.isEmpty()) {
            areaInformacion.append("El inventario está vacío.\n");
        } else {
            for (ElementoBiblioteca elemento : inventario) {
                areaInformacion.append(elemento.toString() + "\n");
            }
        }
    }

    private void buscarElemento() {
        String id = JOptionPane.showInputDialog("Ingrese el ID del elemento:");
        ElementoBiblioteca elemento = biblioteca.buscarElemento(id);

        if (elemento != null) {
            areaInformacion.setText("");
            areaInformacion.append(elemento.toString());
        } else {
            JOptionPane.showMessageDialog(frame, "Elemento no encontrado.");
        }
    }

    private void actualizarElemento() {
        try {
            String id = JOptionPane.showInputDialog("Ingrese el ID del elemento a actualizar:");
            ElementoBiblioteca elemento = biblioteca.buscarElemento(id);

            if (elemento != null) {
                String[] opciones = {"Libro", "Revista", "DVD"};
                String tipo = (String) JOptionPane.showInputDialog(frame, "Seleccione el tipo de elemento", "Actualizar Elemento",
                        JOptionPane.QUESTION_MESSAGE, null, opciones, opciones[0]);

                if (tipo != null) {
                    String titulo = JOptionPane.showInputDialog("Nuevo Título:", elemento.getTitulo());
                    int añoPublicacion = Integer.parseInt(JOptionPane.showInputDialog("Nuevo Año de Publicación:", elemento.getAñoPublicacion()));
                    String nuevoId = JOptionPane.showInputDialog("Nuevo ID:", elemento.getId());

                    switch (tipo) {
                        case "Libro":
                            int numeroPaginas = Integer.parseInt(JOptionPane.showInputDialog("Nuevo Número de Páginas:", ((Libro) elemento).getNumeroPaginas()));
                            biblioteca.actualizarElemento(id, new Libro(titulo, añoPublicacion, nuevoId, numeroPaginas));
                            break;
                        case "Revista":
                            int numeroEjemplares = Integer.parseInt(JOptionPane.showInputDialog("Nuevo Número de Ejemplares:", ((Revista) elemento).getNumeroEjemplares()));
                            biblioteca.actualizarElemento(id, new Revista(titulo, añoPublicacion, nuevoId, numeroEjemplares));
                            break;
                        case "DVD":
                            int duracion = Integer.parseInt(JOptionPane.showInputDialog("Nueva Duración (minutos):", ((DVD) elemento).getDuracion()));
                            biblioteca.actualizarElemento(id, new DVD(titulo, añoPublicacion, nuevoId, duracion));
                            break;
                    }

                    JOptionPane.showMessageDialog(frame, "Elemento actualizado exitosamente.");
                }
            } else {
                JOptionPane.showMessageDialog(frame, "Elemento no encontrado.");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(frame, "Entrada no válida. Intente de nuevo.");
        }
    }

    private void eliminarElemento() {
        String id = JOptionPane.showInputDialog("Ingrese el ID del elemento a eliminar:");
        ElementoBiblioteca elemento = biblioteca.buscarElemento(id);

        if (elemento != null) {
            biblioteca.eliminarElemento(id);
            JOptionPane.showMessageDialog(frame, "Elemento eliminado exitosamente.");
        } else {
            JOptionPane.showMessageDialog(frame, "Elemento no encontrado.");
        }
    }


}
