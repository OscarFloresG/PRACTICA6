import java.io.Serializable;

public class ElementoBiblioteca implements Serializable {
    protected String titulo;
    protected int anioPublicacion;
    protected String id;

    public ElementoBiblioteca(String titulo, int añoPublicacion, String id) {
        this.titulo = titulo;
        this.anioPublicacion = añoPublicacion;
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public int getAñoPublicacion() {
        return anioPublicacion;
    }

    public void setAñoPublicacion(int añoPublicacion) {
        this.anioPublicacion = añoPublicacion;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void mostrarInformacion() {
        System.out.println("ID: " + id);
        System.out.println("Título: " + titulo);
        System.out.println("Año de Publicación: " + anioPublicacion);
    }
}
