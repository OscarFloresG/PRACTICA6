import java.io.Serializable;

public class Revista extends ElementoBiblioteca implements Serializable {
    private int numeroEjemplares;
    private String edicion;
    private String genero;

    public Revista(String titulo, int anioPublicacion, String id, int numeroEjemplares, String edicion, String genero) {
        super(titulo, anioPublicacion, id);
        this.numeroEjemplares = numeroEjemplares;
        this.edicion = edicion;
        this.genero = genero;
    }

    public int getNumeroEjemplares() {
        return numeroEjemplares;
    }

    public void setNumeroEjemplares(int numeroEjemplares) {
        this.numeroEjemplares = numeroEjemplares;
    }

    public String getEdicion() {return edicion;}

    public void setEdicion(String edicion) {this.edicion = edicion;}

    public String getGenero() {return genero;}

    public void setGenero(String genero) {this.genero = genero;}

    @Override
    public String toString() {
        return super.toString() + "\n" +
                "Número de Ejemplares: " + numeroEjemplares + "\n" +
                "Edicion: " + edicion + "\n" +
                "Genero: " + genero;
    }
}
