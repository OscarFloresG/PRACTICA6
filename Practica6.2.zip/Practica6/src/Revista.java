import java.io.Serializable;

public class Revista extends ElementoBiblioteca implements Serializable {
    private int numeroEjemplares;

    public Revista(String titulo, int anioPublicacion, String id, int numeroEjemplares) {
        super(titulo, anioPublicacion, id);
        this.numeroEjemplares = numeroEjemplares;
    }

    public int getNumeroEjemplares() {
        return numeroEjemplares;
    }

    public void setNumeroEjemplares(int numeroEjemplares) {
        this.numeroEjemplares = numeroEjemplares;
    }

    @Override
    public String toString() {
        return super.toString() + "\n" +
                "Número de Ejemplares: " + numeroEjemplares;
    }
}
