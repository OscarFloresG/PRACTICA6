import java.io.Serializable;

public class DVD extends ElementoBiblioteca implements Serializable {
    private int duracion;

    public DVD(String titulo, int anioPublicacion, String id, int duracion) {
        super(titulo, anioPublicacion, id);
        this.duracion = duracion;
    }

    public int getDuracion() {
        return duracion;
    }

    public void setDuracion(int duracion) {
        this.duracion = duracion;
    }

    @Override
    public String toString() {
        return super.toString() + "\n" +
                "Duración: " + duracion + " minutos";
    }
}
