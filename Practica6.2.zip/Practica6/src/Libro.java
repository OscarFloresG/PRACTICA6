import java.io.Serializable;

public class Libro extends ElementoBiblioteca implements Serializable {
    private int numeroPaginas;

    public Libro(String titulo, int anioPublicacion, String id, int numeroPaginas) {
        super(titulo, anioPublicacion, id);
        this.numeroPaginas = numeroPaginas;
    }

    public int getNumeroPaginas() {
        return numeroPaginas;
    }

    public void setNumeroPaginas(int numeroPaginas) {
        this.numeroPaginas = numeroPaginas;
    }

    @Override
    public String toString() {
        return super.toString() + "\n" +
                "Número de Páginas: " + numeroPaginas;
    }
}
