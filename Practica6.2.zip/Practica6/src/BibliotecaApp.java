import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class BibliotecaApp {
    private Biblioteca biblioteca;
    private JFrame frame;
    private JTextArea areaInformacion;

    public BibliotecaApp() {
        biblioteca = new Biblioteca();
        prepararGUI();
    }

    private void prepararGUI() {
        frame = new JFrame("Sistema de Gestión de Biblioteca");
        frame.setSize(800, 1000);
        frame.setLayout(new BorderLayout());

        JPanel panelControl = new JPanel();
        panelControl.setLayout(new FlowLayout());

        JButton btnAgregar = new JButton("Agregar");
        JButton btnMostrar = new JButton("Mostrar");
        JButton btnBuscar = new JButton("Buscar");
        JButton btnActualizar = new JButton("Actualizar");
        JButton btnEliminar = new JButton("Eliminar");

        panelControl.add(btnAgregar);
        panelControl.add(btnMostrar);
        panelControl.add(btnBuscar);
        panelControl.add(btnActualizar);
        panelControl.add(btnEliminar);

        areaInformacion = new JTextArea();
        areaInformacion.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(areaInformacion);

        frame.add(panelControl, BorderLayout.NORTH);
        frame.add(scrollPane, BorderLayout.CENTER);

        // ActionListeners para cada botón
        btnAgregar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                areaInformacion.setText(""); // Limpiar el área de texto
                agregarElemento();
            }
        });

        btnMostrar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mostrarInventario(); // Este botón no limpia el área de texto
            }
        });

        btnBuscar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                areaInformacion.setText(""); // Limpiar el área de texto
                buscarElemento();
            }
        });

        btnActualizar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                areaInformacion.setText(""); // Limpiar el área de texto
                actualizarElemento();
            }
        });

        btnEliminar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                areaInformacion.setText(""); // Limpiar el área de texto
                eliminarElemento();
            }
        });

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }


    private void agregarElemento() {
        try {
            String[] opciones = {"Libro", "Revista", "DVD"};
            String tipo = (String) JOptionPane.showInputDialog(frame, "Seleccione el tipo de elemento", "Agregar Elemento",
                    JOptionPane.QUESTION_MESSAGE, null, opciones, opciones[0]);

            if (tipo != null) {
                String titulo = JOptionPane.showInputDialog("Título:");
                int anioPublicacion = Integer.parseInt(JOptionPane.showInputDialog("Año de Publicación:"));
                String id = JOptionPane.showInputDialog("ID:");

                switch (tipo) {
                    case "Libro":
                        int numeroPaginas = Integer.parseInt(JOptionPane.showInputDialog("Número de Páginas:"));
                        biblioteca.agregarElemento(new Libro(titulo, anioPublicacion, id, numeroPaginas));
                        break;
                    case "Revista":
                        int numeroEjemplares = Integer.parseInt(JOptionPane.showInputDialog("Número de Ejemplares:"));
                        biblioteca.agregarElemento(new Revista(titulo, anioPublicacion, id, numeroEjemplares));
                        break;
                    case "DVD":
                        int duracion = Integer.parseInt(JOptionPane.showInputDialog("Duración (minutos):"));
                        biblioteca.agregarElemento(new DVD(titulo, anioPublicacion, id, duracion));
                        break;
                }

                JOptionPane.showMessageDialog(frame, "Elemento agregado exitosamente.");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(frame, "Entrada no válida. Intente de nuevo.");
        }
    }

    private void mostrarInventario() {
        areaInformacion.setText("");
        ArrayList<ElementoBiblioteca> inventario = biblioteca.getInventario();
        if (inventario.isEmpty()) {
            areaInformacion.append("El inventario está vacío.\n");
        } else {
            for (ElementoBiblioteca elemento : inventario) {
                // Agregar el tipo de objeto al texto mostrado
                if (elemento instanceof Libro) {
                    areaInformacion.append("Tipo: Libro\n");
                } else if (elemento instanceof Revista) {
                    areaInformacion.append("Tipo: Revista\n");
                } else if (elemento instanceof DVD) {
                    areaInformacion.append("Tipo: DVD\n");
                }
                areaInformacion.append(elemento.toString() + "\n");
                areaInformacion.append("\n");
            }
        }
    }


    private void buscarElemento() {
        String id = JOptionPane.showInputDialog("Ingrese el ID del elemento:");
        ElementoBiblioteca elemento = biblioteca.buscarElemento(id);

        if (elemento != null) {
            areaInformacion.setText("");
            areaInformacion.append(elemento.toString());
        } else {
            JOptionPane.showMessageDialog(frame, "Elemento no encontrado.");
        }
    }

    private void actualizarElemento() {
        try {
            String id = JOptionPane.showInputDialog("Ingrese el ID del elemento a actualizar:");
            ElementoBiblioteca elemento = biblioteca.buscarElemento(id);

            if (elemento != null) {
                String[] opciones = {"Libro", "Revista", "DVD"};
                String tipo = (String) JOptionPane.showInputDialog(frame, "Seleccione el tipo de elemento", "Actualizar Elemento",
                        JOptionPane.QUESTION_MESSAGE, null, opciones, opciones[0]);

                if (tipo != null) {
                    String titulo = JOptionPane.showInputDialog("Nuevo Título:", elemento.getTitulo());
                    int anioPublicacion = Integer.parseInt(JOptionPane.showInputDialog("Nuevo Año de Publicación:", elemento.getAnioPublicacion()));
                    String nuevoId = JOptionPane.showInputDialog("Nuevo ID:", elemento.getId());

                    switch (tipo) {
                        case "Libro":
                            int numeroPaginas = Integer.parseInt(JOptionPane.showInputDialog("Nuevo Número de Páginas:", ((Libro) elemento).getNumeroPaginas()));
                            biblioteca.actualizarElemento(id, new Libro(titulo, anioPublicacion, nuevoId, numeroPaginas));
                            break;
                        case "Revista":
                            int numeroEjemplares = Integer.parseInt(JOptionPane.showInputDialog("Nuevo Número de Ejemplares:", ((Revista) elemento).getNumeroEjemplares()));
                            biblioteca.actualizarElemento(id, new Revista(titulo, anioPublicacion, nuevoId, numeroEjemplares));
                            break;
                        case "DVD":
                            int duracion = Integer.parseInt(JOptionPane.showInputDialog("Nueva Duración (minutos):", ((DVD) elemento).getDuracion()));
                            biblioteca.actualizarElemento(id, new DVD(titulo, anioPublicacion, nuevoId, duracion));
                            break;
                    }

                    JOptionPane.showMessageDialog(frame, "Elemento actualizado exitosamente.");
                }
            } else {
                JOptionPane.showMessageDialog(frame, "Elemento no encontrado.");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(frame, "Entrada no válida. Intente de nuevo.");
        }
    }

    private void eliminarElemento() {
        String id = JOptionPane.showInputDialog("Ingrese el ID del elemento a eliminar:");
        ElementoBiblioteca elemento = biblioteca.buscarElemento(id);

        if (elemento != null) {
            biblioteca.eliminarElemento(id);
            JOptionPane.showMessageDialog(frame, "Elemento eliminado exitosamente.");
        } else {
            JOptionPane.showMessageDialog(frame, "Elemento no encontrado.");
        }
    }

}
