import java.io.Serializable;

public class ElementoBiblioteca implements Serializable {
    protected String titulo;
    protected int anioPublicacion;
    protected String id;

    public ElementoBiblioteca(String titulo, int anioPublicacion, String id) {
        this.titulo = titulo;
        this.anioPublicacion = anioPublicacion;
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public int getAnioPublicacion() {
        return anioPublicacion;
    }

    public void setAnioPublicacion(int anioPublicacion) {
        this.anioPublicacion = anioPublicacion;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "ID: " + id + "\n" +
                "Título: " + titulo + "\n" +
                "Año de Publicación: " + anioPublicacion;
    }
}
