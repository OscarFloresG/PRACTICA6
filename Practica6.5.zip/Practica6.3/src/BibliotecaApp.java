import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class BibliotecaApp {
    private Biblioteca biblioteca;
    private JFrame frame;
    private JTextArea areaInformacion;

    public BibliotecaApp() {
        biblioteca = new Biblioteca();
        prepararGUI();
    }

    private void prepararGUI() {
        frame = new JFrame("Sistema de Gestión de Biblioteca");
        frame.setSize(1200, 700);
        frame.setLayout(new BorderLayout());

        // Panel para los botones
        JPanel panelControl = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.setColor(new Color(66, 19, 25));
                g.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        panelControl.setLayout(new GridLayout(5, 1, 10, 10));
        panelControl.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        Dimension buttonSize = new Dimension(250, 60);

        JButton btnAgregar = new JButton("Agregar");
        btnAgregar.setPreferredSize(buttonSize);
        JButton btnMostrar = new JButton("Mostrar");
        btnMostrar.setPreferredSize(buttonSize);
        JButton btnBuscar = new JButton("Buscar");
        btnBuscar.setPreferredSize(buttonSize);
        JButton btnActualizar = new JButton("Actualizar");
        btnActualizar.setPreferredSize(buttonSize);
        JButton btnEliminar = new JButton("Eliminar");
        btnEliminar.setPreferredSize(buttonSize);

        Font buttonFont = new Font("Arial", Font.BOLD, 18);
        btnAgregar.setFont(buttonFont);
        btnMostrar.setFont(buttonFont);
        btnBuscar.setFont(buttonFont);
        btnActualizar.setFont(buttonFont);
        btnEliminar.setFont(buttonFont);

        panelControl.add(btnAgregar);
        panelControl.add(btnMostrar);
        panelControl.add(btnBuscar);
        panelControl.add(btnActualizar);
        panelControl.add(btnEliminar);

        // Panel para la información
        areaInformacion = new JTextArea();
        areaInformacion.setEditable(false);
        areaInformacion.setFont(new Font("Arial", Font.PLAIN, 18));
        areaInformacion.setBorder(BorderFactory.createLineBorder(Color.GRAY, 2));

        JScrollPane scrollPane = new JScrollPane(areaInformacion);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());

        JPanel panelInformacion = new JPanel(new BorderLayout());
        panelInformacion.add(scrollPane, BorderLayout.CENTER);
        panelInformacion.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        frame.add(panelControl, BorderLayout.WEST);
        frame.add(panelInformacion, BorderLayout.CENTER);

        // ActionListeners para cada botón
        btnAgregar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                areaInformacion.setText(""); // Limpiar el área de texto
                agregarElemento();
            }
        });

        btnMostrar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mostrarInventario(); // Este botón no limpia el área de texto
            }
        });

        btnBuscar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                areaInformacion.setText(""); // Limpiar el área de texto
                buscarElemento();
            }
        });

        btnActualizar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                areaInformacion.setText(""); // Limpiar el área de texto
                actualizarElemento();
            }
        });

        btnEliminar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                areaInformacion.setText(""); // Limpiar el área de texto
                eliminarElemento();
            }
        });

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }

    private void agregarElemento() {
        try {
            String[] opciones = {"Libro", "Revista", "DVD"};
            String tipo = (String) JOptionPane.showInputDialog(frame, "Seleccione el tipo de elemento", "Agregar Elemento",
                    JOptionPane.QUESTION_MESSAGE, null, opciones, opciones[0]);

            if (tipo != null) {
                String titulo = JOptionPane.showInputDialog("Título:");
                int anioPublicacion = Integer.parseInt(JOptionPane.showInputDialog("Año de Publicación:"));
                String id = JOptionPane.showInputDialog("ID:");
                String autor = JOptionPane.showInputDialog("Autor:");

                if (biblioteca.buscarElemento(id) != null) {
                    JOptionPane.showMessageDialog(frame, "Ya existe un elemento con ese ID. Por favor, use un ID diferente.");
                    return;
                }

                switch (tipo) {
                    case "Libro":
                        int numeroPaginas = Integer.parseInt(JOptionPane.showInputDialog("Número de Páginas:"));
                        String edicion = JOptionPane.showInputDialog("Edición:");
                        String editorial = JOptionPane.showInputDialog("Editorial:");
                        biblioteca.agregarElemento(new Libro(titulo, anioPublicacion, id, autor, numeroPaginas, edicion, editorial));
                        break;
                    case "Revista":
                        int numeroEjemplares = Integer.parseInt(JOptionPane.showInputDialog("Número de Ejemplares:"));
                        String edicionR = JOptionPane.showInputDialog("Edición:");
                        String genero = JOptionPane.showInputDialog("Género:");
                        biblioteca.agregarElemento(new Revista(titulo, anioPublicacion, id, autor, numeroEjemplares, edicionR, genero));
                        break;
                    case "DVD":
                        int duracion = Integer.parseInt(JOptionPane.showInputDialog("Duración (minutos):"));
                        String idioma = JOptionPane.showInputDialog("Idioma:");
                        String clasificacion = JOptionPane.showInputDialog("Clasificación:");
                        biblioteca.agregarElemento(new DVD(titulo, anioPublicacion, id, autor, duracion, idioma, clasificacion));
                        break;
                }

                JOptionPane.showMessageDialog(frame, "Elemento agregado exitosamente.");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(frame, "Entrada no válida. Intente de nuevo.");
        }
    }

    private void mostrarInventario() {
        ArrayList<ElementoBiblioteca> elementos = biblioteca.getElementos();
        if (elementos.isEmpty()) {
            areaInformacion.setText("No hay elementos en la biblioteca.");
        } else {
            areaInformacion.setText("");
            for (ElementoBiblioteca elemento : elementos) {
                areaInformacion.append(elemento.toString() + "\n\n");
            }
        }
    }

    private void buscarElemento() {
        String id = JOptionPane.showInputDialog("Ingrese el ID del elemento a buscar:");
        ElementoBiblioteca elemento = biblioteca.buscarElemento(id);

        if (elemento != null) {
            areaInformacion.setText(elemento.toString());
        } else {
            JOptionPane.showMessageDialog(frame, "Elemento no encontrado.");
        }
    }

    private void actualizarElemento() {
        try {
            String id = JOptionPane.showInputDialog("Ingrese el ID del elemento a actualizar:");
            ElementoBiblioteca elemento = biblioteca.buscarElemento(id);

            if (elemento != null) {
                String[] opciones = {"Libro", "Revista", "DVD"};
                String tipo = (String) JOptionPane.showInputDialog(frame, "Seleccione el tipo de elemento", "Actualizar Elemento",
                        JOptionPane.QUESTION_MESSAGE, null, opciones, opciones[0]);

                if (tipo != null) {
                    String titulo = JOptionPane.showInputDialog("Nuevo Título:", elemento.getTitulo());
                    int anioPublicacion = Integer.parseInt(JOptionPane.showInputDialog("Nuevo Año de Publicación:", elemento.getAnioPublicacion()));
                    String nuevoId = JOptionPane.showInputDialog("Nuevo ID:");
                    String autor = JOptionPane.showInputDialog("Nuevo Autor:", elemento.getAutor());

                    if (!nuevoId.equals(id) && biblioteca.buscarElemento(nuevoId) != null) {
                        JOptionPane.showMessageDialog(frame, "Ya existe un elemento con ese nuevo ID. Por favor, use un ID diferente.");
                        return;
                    }

                    switch (tipo) {
                        case "Libro":
                            int numeroPaginas = Integer.parseInt(JOptionPane.showInputDialog("Nuevo Número de Páginas:"));
                            String edicion = JOptionPane.showInputDialog("Edición:");
                            String editorial = JOptionPane.showInputDialog("Editorial:");
                            biblioteca.actualizarElemento(id, new Libro(titulo, anioPublicacion, nuevoId, autor, numeroPaginas, edicion, editorial));
                            break;
                        case "Revista":
                            int numeroEjemplares = Integer.parseInt(JOptionPane.showInputDialog("Nuevo Número de Ejemplares:"));
                            String edicionR = JOptionPane.showInputDialog("Edición:");
                            String genero = JOptionPane.showInputDialog("Género:");
                            biblioteca.actualizarElemento(id, new Revista(titulo, anioPublicacion, nuevoId, autor, numeroEjemplares, edicionR, genero));
                            break;
                        case "DVD":
                            int duracion = Integer.parseInt(JOptionPane.showInputDialog("Nueva Duración (minutos):"));
                            String idioma = JOptionPane.showInputDialog("Idioma:");
                            String clasificacion = JOptionPane.showInputDialog("Clasificación:");
                            biblioteca.actualizarElemento(id, new DVD(titulo, anioPublicacion, nuevoId, autor, duracion, idioma, clasificacion));
                            break;
                    }

                    JOptionPane.showMessageDialog(frame, "Elemento actualizado exitosamente.");
                }
            } else {
                JOptionPane.showMessageDialog(frame, "Elemento no encontrado.");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(frame, "Entrada no válida. Intente de nuevo.");
        }
    }

    private void eliminarElemento() {
        String id = JOptionPane.showInputDialog("Ingrese el ID del elemento a eliminar:");
        ElementoBiblioteca elemento = biblioteca.buscarElemento(id);

        if (elemento != null) {
            biblioteca.eliminarElemento(id);
            JOptionPane.showMessageDialog(frame, "Elemento eliminado exitosamente.");
        } else {
            JOptionPane.showMessageDialog(frame, "Elemento no encontrado.");
        }
    }

}
