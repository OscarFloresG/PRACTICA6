import java.io.*;
import java.util.ArrayList;

public class Biblioteca {
    private ArrayList<ElementoBiblioteca> elementos;
    private final String archivo = "biblioteca.ser";

    public Biblioteca() {
        elementos = new ArrayList<>();
        cargarDatos();
    }

    public void agregarElemento(ElementoBiblioteca elemento) {
        if (buscarElemento(elemento.getId()) != null) {
            throw new IllegalArgumentException("Ya existe un elemento con ese ID.");
        }
        elementos.add(elemento);
        guardarDatos();
    }

    public void eliminarElemento(String id) {
        elementos.removeIf(elemento -> elemento.getId().equals(id));
        guardarDatos();
    }

    public void actualizarElemento(String id, ElementoBiblioteca elementoActualizado) {
        for (int i = 0; i < elementos.size(); i++) {
            if (elementos.get(i).getId().equals(id)) {
                elementos.set(i, elementoActualizado);
                guardarDatos(); // Asegurarse de guardar después de actualizar
                return;
            }
        }
    }

    public ElementoBiblioteca buscarElemento(String id) {
        for (ElementoBiblioteca elemento : elementos) {
            if (elemento.getId().equals(id)) {
                return elemento;
            }
        }
        return null;
    }

    public ArrayList<ElementoBiblioteca> getElementos() {
        return elementos;
    }

    private void guardarDatos() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(archivo))) {
            oos.writeObject(elementos);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void cargarDatos() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(archivo))) {
            elementos = (ArrayList<ElementoBiblioteca>) ois.readObject();
        } catch (FileNotFoundException e) {
            // Si el archivo no existe, se ignora
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
