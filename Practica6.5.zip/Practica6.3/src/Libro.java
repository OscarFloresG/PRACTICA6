import java.io.Serializable;

public class Libro extends ElementoBiblioteca implements Serializable {
    private int numeroPaginas;
    private String edicion;
    private String editorial;

    public Libro(String titulo, int anioPublicacion, String id, String autor, int numeroPaginas, String edicion, String editorial) {
        super(titulo, anioPublicacion, id, autor); // Incluir autor
        this.numeroPaginas = numeroPaginas;
        this.edicion = edicion;
        this.editorial = editorial;
    }

    public int getNumeroPaginas() {
        return numeroPaginas;
    }

    public void setNumeroPaginas(int numeroPaginas) {
        this.numeroPaginas = numeroPaginas;
    }

    public String getEdicion() {
        return edicion;
    }

    public void setEdicion(String edicion) {
        this.edicion = edicion;
    }

    public String getEditorial() {
        return editorial;
    }

    public void setEditorial(String editorial) {
        this.editorial = editorial;
    }

    @Override
    public String toString() {
        return super.toString() + "\n" +
                "Número de Páginas: " + numeroPaginas + "\n" +
                "Edición: " + edicion + "\n" +
                "Editorial: " + editorial + "\n";
    }
}
