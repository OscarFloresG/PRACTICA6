import java.io.Serializable;

public class ElementoBiblioteca implements Serializable {
    protected String titulo;
    protected int anioPublicacion;
    protected String id;
    protected String autor; // Nuevo atributo

    public ElementoBiblioteca(String titulo, int anioPublicacion, String id, String autor) {
        this.titulo = titulo;
        this.anioPublicacion = anioPublicacion;
        this.id = id;
        this.autor = autor; // Inicializar nuevo atributo
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public int getAnioPublicacion() {
        return anioPublicacion;
    }

    public void setAnioPublicacion(int anioPublicacion) {
        this.anioPublicacion = anioPublicacion;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getAutor() { // Nuevo getter
        return autor;
    }

    public void setAutor(String autor) { // Nuevo setter
        this.autor = autor;
    }

    @Override
    public String toString() {
        return "ID: " + id + "\n" +
                "Título: " + titulo + "\n" +
                "Autor: " + autor + "\n" + // Incluir en toString
                "Año de Publicación: " + anioPublicacion;
    }
}
