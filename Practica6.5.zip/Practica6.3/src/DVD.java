import java.io.Serializable;

public class DVD extends ElementoBiblioteca implements Serializable {
    private int duracion;
    private String idioma;
    private String clasificacion;

    public DVD(String titulo, int anioPublicacion, String id, String autor, int duracion, String idioma, String clasificacion) {
        super(titulo, anioPublicacion, id, autor); // Incluir autor
        this.duracion = duracion;
        this.idioma = idioma;
        this.clasificacion = clasificacion;
    }

    public int getDuracion() {
        return duracion;
    }

    public void setDuracion(int duracion) {
        this.duracion = duracion;
    }

    public String getIdioma() {
        return idioma;
    }

    public void setIdioma(String idioma) {
        this.idioma = idioma;
    }

    public String getClasificacion() {
        return clasificacion;
    }

    public void setClasificacion(String clasificacion) {
        this.clasificacion = clasificacion;
    }

    @Override
    public String toString() {
        return super.toString() + "\n" +
                "Duración: " + duracion + " minutos\n" +
                "Idioma: " + idioma + "\n" +
                "Clasificación: " + clasificacion + "\n";
    }
}
